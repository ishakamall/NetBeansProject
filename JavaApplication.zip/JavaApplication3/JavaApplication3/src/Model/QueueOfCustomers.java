package Model;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class QueueOfCustomers {
    private Queue<Customer> customers;

    public QueueOfCustomers() {
        this.customers = new LinkedList<>();
    }

    public void enqueue(Customer customer) {
        customers.add(customer);
    }

    public Customer dequeue() {
        return customers.poll();
    }

    public Customer findCustomerById(String id) {
        for (Customer customer : customers) {
            if (customer.getParcelId().equals(id)) {
                return customer;
            }
        }
        return null;
    }

    public boolean remove(String parcelId) {
        Iterator<Customer> it = customers.iterator();
        while (it.hasNext()) {
            if (it.next().getParcelId().equals(parcelId)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    public void updateCustomer(String parcelId, String newName) {
        Customer customer = findCustomerById(parcelId);
        if (customer != null) {
            customer.setName(newName);
        }
    }

    public boolean isEmpty() {
        return customers.isEmpty();
    }

    public int getSize() {
        return customers.size();
    }

    // To display all customers in the queue
    public String displayAll() {
        StringBuilder sb = new StringBuilder();
        for (Customer customer : customers) {
            sb.append("Queue Number: ").append(customer.getQueueNumber())
              .append(", Name: ").append(customer.getName())
              .append(", Parcel ID: ").append(customer.getParcelId()).append("\n");
        }
        return sb.toString();
    }
}


package Model;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import Utility.Log;


public class Customer {
    private int queueNumber;
    private String name;
    private String parcelId;

    public Customer(int queueNumber, String name, String parcelId) {
        this.queueNumber = queueNumber;
        this.name = name;
        this.parcelId = parcelId;
    }

    
        public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty.");
        }
        this.name = name;
    }
 
    public void setQueueNumber(int queueNumber) {
        this.queueNumber = queueNumber;
    }
    
    public int getQueueNumber() {
        return queueNumber;
    }

    public String getName() {
        return name;
    }
    
    

    public String getParcelId() {
        return parcelId;
    }
    
     // Method to remove customer, place this in Customer class
    public void removeCustomer(int selectedRow, DefaultTableModel customerTableModel, DefaultTableModel parcelTableModel, ParcelMap parcelMap, QueueOfCustomers queueOfCustomers) {
        if (selectedRow >= 0) {
            String customerId = customerTableModel.getValueAt(selectedRow, 2).toString(); // Assuming ID is at column index 2
            String parcelId = customerTableModel.getValueAt(selectedRow, 2).toString(); // Parcel ID is the same as customer ID

            // Find the associated parcel and mark it as "Unprocessed"
            Parcel parcel = parcelMap.findParcel(parcelId);
            if (parcel != null) {
                parcel.setStatus("Unprocessed"); // Update the parcel status to Unprocessed

                // Update the parcel status in the parcel table
                for (int i = 0; i < parcelTableModel.getRowCount(); i++) {
                    if (parcelTableModel.getValueAt(i, 0).equals(parcelId)) { // Match by Parcel ID
                        parcelTableModel.setValueAt("Unprocessed", i, 6); // Update the "Status" column
                        break;
                    }
                }
            }

            // Now remove the customer from the table and file
            customerTableModel.removeRow(selectedRow);
            if (removeCustomerFromFile(customerId)) {
                queueOfCustomers.remove(customerId); // Only remove from the queue if successfully removed from the file
                Log.getInstance().log("Removed customer: " + customerId);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to remove customer from file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No customer selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Assuming you have this method to remove a customer from a file
    private boolean removeCustomerFromFile(String customerId) {
        // Implement the logic to remove the customer from the file
        return true; // Placeholder, return true if successful
    }
    

}


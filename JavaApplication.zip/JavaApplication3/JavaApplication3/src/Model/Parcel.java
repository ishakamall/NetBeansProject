package Model;

public class Parcel {
    private String id;
    private int daysInDepot;
    private double weight;
    private int length, width, height;
    private String status; // Possible values could include "Received", "In Transit", "Delivered", "Processed"

    public Parcel(String id, int daysInDepot, double weight, int length, int width, int height) {
        this.id = id;
        this.daysInDepot = daysInDepot;
        this.weight = weight;
        this.length = length;
        this.width = width;
        this.height = height;
        this.status = "Received"; // Default status when a parcel is created
    }

    // Getters
    public String getId() {
        return id;
    }

    public int getDaysInDepot() {
        return daysInDepot;
    }

    public double getWeight() {
        return weight;
    }

    public int getLength() {
        return length;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setDaysInDepot(int daysInDepot) {
        if (daysInDepot < 0) throw new IllegalArgumentException("Days in depot cannot be negative.");
        this.daysInDepot = daysInDepot;
    }

    public void setWeight(double weight) {
        if (weight < 0) throw new IllegalArgumentException("Weight cannot be negative.");
        this.weight = weight;
    }

    public void setDimensions(int length, int width, int height) {
        if (length < 0 || width < 0 || height < 0) {
            throw new IllegalArgumentException("Dimensions cannot be negative.");
        }
        this.length = length;
        this.width = width;
        this.height = height;
    }

  public void setStatus(String status) {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Status cannot be null or empty.");
        }
        this.status = status;
    }

    public void markAsProcessed() {
        this.status = "Processed";
    }

}


package Controller;
import Model.ParcelMap;
import View.DepotView;
import Model.Parcel;
import Model.QueueOfCustomers;
import Model.Customer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Manager {
    private static DepotView view;
    private static Worker worker;
    private static ParcelMap parcelMap;
    private static QueueOfCustomers queueOfCustomers;

    public static void main(String[] args) {
        parcelMap = new ParcelMap();
        queueOfCustomers = new QueueOfCustomers();
        worker = new Worker(parcelMap);
        view = new DepotView();

        // Load data from CSV files
        loadParcels("src/Parcels.csv");  // Update the path as needed
        loadCustomers("src/Custs.csv");  // Update the path as needed

        // Display the GUI
        java.awt.EventQueue.invokeLater(() -> view.setVisible(true));

        // Sample to show customers in the GUI, for demonstration
    //    view.updateCustomerArea(queueOfCustomers.displayAll());
        
        
    }

    private static void loadParcels(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 6) {
                    Parcel parcel = new Parcel(data[0].trim(), Integer.parseInt(data[1].trim()), 
                                               Double.parseDouble(data[2].trim()), 
                                               Integer.parseInt(data[3].trim()), 
                                               Integer.parseInt(data[4].trim()), 
                                               Integer.parseInt(data[5].trim()));
                    parcelMap.addParcel(parcel);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadCustomers(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length == 3) {
                    Customer customer = new Customer(Integer.parseInt(data[0].trim()), data[1].trim(), data[2].trim());
                    queueOfCustomers.enqueue(customer);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
